<?php
header ('Location:https://phpmu.com/');
?>